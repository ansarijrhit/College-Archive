let counter = 0;
setInterval(() => {
    counter++;
    console.log("counter", counter);
}, 500);
console.log("Hello CSSE 280!");